package com.ims.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ims.bean.VendorBean;
import com.ims.servicefactory.ServiceFactory;
import com.ims.services.VendorService;

public class AddVendorDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");		
		
		String vendorID=request.getParameter("vendorId");
		String vendorName=request.getParameter("vendorName");		
		String vendorAddress=request.getParameter("vendorAddress");	
		String vendorPhoneNumber=request.getParameter("vendorPhoneNumber");
		
		VendorBean addvendor=new VendorBean();
		
		addvendor.setVendorID(vendorID);
		addvendor.setVendorName(vendorName);	
		addvendor.setVendorAddress(vendorAddress);
		addvendor.setVendorPhoneNumber(vendorPhoneNumber);		
		
		VendorService vendorService = ServiceFactory.getVendorService();
		
		try {
			vendorService.addVendor(addvendor);
			System.out.println("vendor added successfully");
			RequestDispatcher rd=request.getRequestDispatcher("VendorDetailsScreen.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {			
			e.printStackTrace();
                        RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
                        
		}
		
		
					 
		
		
	}
		
	}

