package com.ims.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ims.bean.ItemBean;
import com.ims.servicefactory.ServiceFactory;
import com.ims.services.ItemService;


public class ModifyItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	response.setContentType("text/html");
	
	String itemID=request.getParameter("itemid");
	String itemName=request.getParameter("newitemname");
	String itemType=request.getParameter("newitemtype");
	String itemprice=request.getParameter("newitemprice");
	String itemQuantity=request.getParameter("newitemquantity");
	String vendorID=request.getParameter("newvendorid");	
	String warehouseID=request.getParameter("newwarehouseid");	
	
	ItemBean modifyitem=new ItemBean();
	
	modifyitem.setItemID(itemID);
	modifyitem.setItemName(itemName);
	modifyitem.setItemType(itemType);
	modifyitem.setPrice(itemprice);
	modifyitem.setQuantity(itemQuantity);
	modifyitem.setVendorID(vendorID);
	modifyitem.setWarehouseID(warehouseID);		
	
	ItemService itemService = ServiceFactory.getItemService();
	try{
		itemService.modifyItem(itemID,modifyitem);
	}
	catch (SQLException e) {			
		e.printStackTrace();
                RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
	} catch (ClassNotFoundException e) {			
		e.printStackTrace();
	}
	/*request.setAttribute("rs", rs);*/
	System.out.println("item modified successfully");
	

	RequestDispatcher rd=request.getRequestDispatcher("ItemDetailsScreen.jsp");
	rd.forward(request, response);
}

}
