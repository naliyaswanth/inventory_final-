package com.ims.controllers;

import com.ims.bean.WarehouseBean;
import com.ims.servicefactory.ServiceFactory;
import com.ims.services.WarehouseService;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ModifyWarehouse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		String warehouseID=request.getParameter("newwarehouseid");
		String warehouseName=request.getParameter("newwarehousename");		
		String warehouseCapacity=request.getParameter("newwarehousecapacity");	
		String warehouseAddress=request.getParameter("newwarehouseaddress");
		
		
		WarehouseBean modifywarehouse = new WarehouseBean();
		
		modifywarehouse.setWarehouseID(warehouseID);
		modifywarehouse.setWarehouseName(warehouseName);	
		modifywarehouse.setWarehouseCapacity(warehouseCapacity);
		modifywarehouse.setWarehouseAddress(warehouseAddress);		
		
		WarehouseService warehouseService = ServiceFactory.getWarehouseService();
		
		
		try{
			warehouseService.modifyWarehouse(warehouseID, modifywarehouse);
		}
		catch (SQLException e) {			
			e.printStackTrace();
                        RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
		}
		/*request.setAttribute("rs", rs);*/
		System.out.println("item modified successfully");
		

		RequestDispatcher rd=request.getRequestDispatcher("WarehouseDetailsScreen.jsp");
		rd.forward(request, response);
	}

}
