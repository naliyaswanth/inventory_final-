package com.ims.controllers;

import com.ims.bean.RegistrationBean;

import com.ims.servicefactory.ServiceFactory;
import com.ims.services.RegistrationService; 

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ims.utilty.DBUtility;

public class RegistrationController extends HttpServlet {
	boolean insertResult;
        @Override
	    public void init(){
            	  
              }
              
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
   
       public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
         	   
                
                    String username=request.getParameter("username");
                    String  password=request.getParameter("pwd");
            	    String dateOfBirth=request.getParameter("dob");
            	    String emailId=request.getParameter("email");
            	    String contact=request.getParameter("tel");
            	    String address=request.getParameter("address");
                    String  postcode=request.getParameter("postcode");
            	    String role=request.getParameter("role");
            	    
            	    
            	   RegistrationBean register=new RegistrationBean();
                  
            	   register.setUserName(username);
                   register.setPassword(password);
            	   register.setDateOfBirth(dateOfBirth);
            	   register.setEmailId(emailId);
            	   register.setContactNumber(contact);
            	   register.setAddress(address);
                   register.setPostcode(postcode);
            	
            	   
            	   
            	  RegistrationService registerService=new RegistrationService();
            	  try{
            		insertResult=registerService.InsertDetails(register);
            		//al=registerService.RegisteredDetails(register);            		
            	  }
            	    
            	  catch(ClassNotFoundException ce ){
   		           ce.printStackTrace();
   		           // append message to log file
   		       }
   		       catch(SQLException se){
   		           se.printStackTrace( );
   		           // append message to log file
   		       }
   		    if(insertResult){
   			request.setAttribute("result1",insertResult);
   		       RequestDispatcher rd = request.getRequestDispatcher("Registered.jsp");
   		       rd.forward(request, response);

   		    }
   		    else{
   		    	RequestDispatcher rd = request.getRequestDispatcher("signup.html");
   			       rd.forward(request, response);

   		    }
   		   		    
   		
    }
}    


