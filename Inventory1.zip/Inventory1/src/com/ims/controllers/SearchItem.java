package com.ims.controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ims.bean.ItemBean;
//import com.ims.bean.VendorBean;
import com.ims.services.ItemService;
//import com.ims.services.VendorService;

public class SearchItem extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SearchItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		String itemID = request.getParameter("ItemId");
        System.out.println(itemID);
		ItemBean searchitem = new ItemBean();
		searchitem.setItemID(itemID);
		try {
			ItemService itemservice = new ItemService();
			ResultSet rs = itemservice.searchItem(searchitem);
			request.setAttribute("rs", rs);
			System.out.println("searched successfully");
			RequestDispatcher rd = request.getRequestDispatcher("SearchByItem.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("Sqlexception.jsp");
			rd.forward(request, response);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}
}
