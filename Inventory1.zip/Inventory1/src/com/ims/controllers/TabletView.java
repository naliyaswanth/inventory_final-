/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ims.servicefactory.ServiceFactory;
import com.ims.services.ItemService;
/**
 *
 * @author techm
 */
public class TabletView extends HttpServlet {
 
	private static final long serialVersionUID = 1L;

  
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		
		ItemService itemService = ServiceFactory.getItemService();
		ResultSet rs=null;
		
		try
		{
			rs=itemService.filterItemA();
			System.out.println("returned");
			request.setAttribute("rs", rs);
		    RequestDispatcher rd=request.getRequestDispatcher("TabletDetailScreen.jsp");
		      rd.forward(request, response);
		}
		
		catch(ClassNotFoundException ce)
	    {
	            ce.printStackTrace();
                    RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
	    }
	    catch(SQLException se)
	    {
	        	se.printStackTrace();
	    }
	   
        }
		//response.sendRedirect("ItemDetailsScreen.jsp");
				
	
}
  

