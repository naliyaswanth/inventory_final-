/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.daoImplementations;

/**
 *
 * @author techm
 */
import com.ims.bean.RegistrationBean;
import com.ims.daointerfaces.RegistrationDao;
import com.ims.utilty.DBUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegistrationDaoImplementation implements RegistrationDao {
    
     Connection con=null;
	// PreparedStatement ps=null;
	    
	    ResultSet rs=null;
    @Override
	 public boolean InsertDetails(RegistrationBean register){
		 System.out.println("------------23423");
		 System.out.println(register);
                 
                 
		 String username=register.getUserName();
                 String password=register.getPassword();
		 String  dob=register.getDateOfBirth();
		 String emailid=register.getEmailId();
		 String contact=register.getContactNumber();
		 String address=register.getAddress();
                 String postcode=register.getPostCode();
		 
		 
		 boolean status;
		 
		  try{
                 
	          con=DBUtility.getConnection();
	          PreparedStatement ps1=con.prepareStatement("insert into RegistrationDetails values(?,?,?,?,?,?,?)");
	          ps1.setString(1,register.getUserName());
	         
	          ps1.setString(2,register.getPassword());
	           
	          ps1.setString(3,register.getDateOfBirth());
	          
	          ps1.setString(4,register.getEmailId());
	         
	          ps1.setString(5,register.getContactNumber());
	       
	          ps1.setString(6,register.getAddress());
	        
                  ps1.setString(7,register.getPostCode() );
   
      
	       
	           int stat=ps1.executeUpdate();
	           System.out.println("entered");
	           System.out.println("-----------------------------------");
	           System.out.println(stat);
	          con.commit();
	          String msg=" ";
	          if(stat!=0){  
	            msg="Record has been inserted";
	            //\\ps1.println("<font size='6' color=blue>" + msg + "</font>");  


	          }  
	          else{  
	            msg="failed to insert the data";
	            //ps1.println("<font size='6' color=blue>" + msg + "</font>");
	           }  
	          //pst.close();
	           System.out.println("stat"+stat);
		  
		  System.out.println("welcome");
		  try{
			  System.out.println("welcome");
             PreparedStatement ps2=con.prepareStatement("insert into LoginDetails  values(?,?,'user')");
             ps2.setString(1,register.getUserName());
             ps2.setString(2,register.getPassword());
           //  ps2.setString(3, "Developer");
          //   ps2.setString(3, devReg.getRole());
             int s=ps2.executeUpdate();
             System.out.println("come");
             con.commit();
             
             
             System.out.println("s"+s);
           
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		 
	 
	 return true;
	 }
	    
    
}
