package com.ims.daointerfaces;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.ItemBean;

public interface ItemDao {

	public abstract void addItem(ItemBean item) throws ClassNotFoundException, SQLException;
	public abstract void modifyItem(String itemID,ItemBean item)throws ClassNotFoundException, SQLException;
	public abstract void deleteItem(ItemBean item)throws ClassNotFoundException, SQLException;
	public abstract ResultSet viewItem()throws ClassNotFoundException, SQLException;
	public abstract ResultSet searchItem(ItemBean item)throws ClassNotFoundException, SQLException;
	public abstract ResultSet filterItemA() throws ClassNotFoundException,SQLException;
	public abstract ResultSet filterItemB() throws ClassNotFoundException,SQLException;
	public abstract ResultSet filterItemC() throws ClassNotFoundException,SQLException;
}
