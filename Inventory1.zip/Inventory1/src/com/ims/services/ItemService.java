package com.ims.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.ItemBean;
import com.ims.daofactory.DaoFactory;
import com.ims.daointerfaces.ItemDao;

public class ItemService {

	public void  addItem(ItemBean item) throws SQLException, ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		itemdao.addItem(item);
	}
		
	public void modifyItem(String itemID,ItemBean item) throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		itemdao.modifyItem(itemID,item);
	}
	
	public void deleteItem(ItemBean item) throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		itemdao.deleteItem(item);
	}
	
	public ResultSet viewItem() throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		return itemdao.viewItem();
	}
	
	public ResultSet searchItem(ItemBean item) throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		return itemdao.searchItem(item);
	}
		//public ResultSet searchItemW(ItemBean item) throws SQLException,ClassNotFoundException{
			//ItemDao itemdao=DaoFactory.getItemDao();
			//return itemdao.searchItemW(item);
        public ResultSet filterItemA() throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		return itemdao.filterItemA();
        }
	public ResultSet filterItemB() throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		return itemdao.filterItemB();
        }	
        public ResultSet filterItemC() throws SQLException,ClassNotFoundException{
		ItemDao itemdao=DaoFactory.getItemDao();
		return itemdao.filterItemC();
        }
	}
