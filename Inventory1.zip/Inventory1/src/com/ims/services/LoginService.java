package com.ims.services;

import java.sql.SQLException;

import com.ims.bean.LoginBean;
import com.ims.daofactory.DaoFactory;
import com.ims.daointerfaces.LoginDao;

public class LoginService {

	public String validateUser(LoginBean login) throws ClassNotFoundException, SQLException{
		
	LoginDao loginDao=DaoFactory.getLoginDao();
	return loginDao.validateUser(login);
	}
}
