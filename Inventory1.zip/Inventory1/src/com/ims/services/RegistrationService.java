/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.services;

import java.sql.SQLException;

import com.ims.bean.RegistrationBean;
import com.ims.daoImplementations.RegistrationDaoImplementation;
import com.ims.daofactory.DaoFactory;
import com.ims.daointerfaces.RegistrationDao;

public class RegistrationService {

	public boolean InsertDetails(RegistrationBean register) throws  ClassNotFoundException,SQLException{
    	   RegistrationDao registerDao=new RegistrationDaoImplementation();
    	    return registerDao.InsertDetails(register);
	}
}

