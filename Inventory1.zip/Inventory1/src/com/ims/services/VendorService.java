package com.ims.services;

import com.ims.bean.VendorBean;
import com.ims.daofactory.DaoFactory;
import com.ims.daointerfaces.VendorDao;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VendorService {

	public void  addVendor(VendorBean vendor) throws SQLException, ClassNotFoundException{
		VendorDao vendordao=DaoFactory.getVendorDao();
		vendordao.addVendor(vendor);
	}
		
	public void modifyVendor(String vendorID, VendorBean vendor) throws SQLException,ClassNotFoundException{
		VendorDao vendordao=DaoFactory.getVendorDao();
		vendordao.modifyVendor(vendorID, vendor);
	}
	
	public void deleteVendor(VendorBean vendor) throws SQLException,ClassNotFoundException{
		VendorDao vendordao=DaoFactory.getVendorDao();
		vendordao.deleteVendor(vendor);
	}
	
	public ResultSet viewVendor() throws SQLException,ClassNotFoundException{
		VendorDao vendordao=DaoFactory.getVendorDao();
		return vendordao.viewVendor();
	}
	
	public ResultSet searchVendor(VendorBean vendor) throws SQLException,ClassNotFoundException{
		VendorDao vendordao=DaoFactory.getVendorDao();
		return vendordao.searchVendor(vendor);
		
	}
	
}
