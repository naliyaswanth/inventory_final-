package com.ims.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.WarehouseBean;
import com.ims.daofactory.DaoFactory;
import com.ims.daointerfaces.WarehouseDao;

public class WarehouseService {

	public void  addWarehouse(WarehouseBean warehouse) throws SQLException, ClassNotFoundException{
		WarehouseDao warehousedao=DaoFactory.getWarehouseDao();
		warehousedao.addWarehouse(warehouse);
	}
		
	public void modifyWarehouse(String warehouseID, WarehouseBean warehouse) throws SQLException,ClassNotFoundException{
		WarehouseDao warehousedao=DaoFactory.getWarehouseDao();
		warehousedao.modifyWarehouse(warehouseID, warehouse);
	}
	
	public void deleteWarehouse(WarehouseBean warehouse) throws SQLException,ClassNotFoundException{
		WarehouseDao warehousedao=DaoFactory.getWarehouseDao();
		warehousedao.deleteWarehouse(warehouse);
	}
	
	public ResultSet viewWarehouse() throws SQLException,ClassNotFoundException{
		WarehouseDao warehousedao=DaoFactory.getWarehouseDao();
		return warehousedao.viewWarehouse();
	}
	
	public ResultSet searchWarehouse(WarehouseBean warehouse) throws SQLException,ClassNotFoundException{
		WarehouseDao warehousedao=DaoFactory.getWarehouseDao();

		return warehousedao.searchWarehouse(warehouse);
	}
	
}
